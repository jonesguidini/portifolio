<?php
require_once('phpmailer/class.phpmailer.php');
include("phpmailer/class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$nome = $_POST['nome'];
$email = $_POST['email'];
$ddd = $_POST['ddd'];
$telefone = $_POST['telefone'];
$mensagem = nl2br(strip_tags($_POST['mensagem']));


$mail = new PHPMailer();
$mail->Mailer = "smtp";
$mail->IsHTML(true);


$mail->Host = "mail.samaritanodf.org.br"; //  se tiver CPANEL provavelmente possa ser mail.seudominio.com ou .com.br
$mail->Port = 26;
$mail->SMTPAuth = true;
$mail->Username = "naoresponda@samaritanodf.org.br"; // exemplo: tu@teudominio.com.br ou .com :)
$mail->Password = "naoresponda";

$mail->From = $mail->Username;
$mail->FromName   = $nome;
//$mail->AddAddress("jguidini@hotmail.com","Jos� Guidini");
$mail->AddAddress("atendimento@samaritanodf.org.br","Atendimento");
$mail->AddCC('jonesguidini@gmail.com', 'Visuweb');
$mail->AddCC('roniltoncardoso@hotmail.com', 'Ronilton');

$mail->AddReplyTo($email, $nome); // Para quando responder, n�o v� para o email de autentica��o

$mail->Subject    = "MENSAGEM ENVIADO PELO SITE - SAMARITANODF.ORG.BR";
$mail->AltBody    = "AQUI VAI A MENSAGEM!"; // optional, comment out and test

$body = "
<h3>MENSAGEM ENVIADA PELO SITE www.samaritanodf.org.br!</h3>
<table border='0' cellpading='6' cellspacing='0' width='600'>
<tr>
<td width='75' style='padding: 6px; border: 1px solid #ccc;'><b>Nome:</b></td>
<td style='padding: 6px; border: 1px solid #ccc;'> $nome </td>
</tr>
<tr>
<td style='padding: 6px; border: 1px solid #ccc;'><b>Email:</b></td> 
<td style='padding: 6px; border: 1px solid #ccc;'>$email </td>
</tr>
<tr>
<td style='padding: 6px; border: 1px solid #ccc;'><b>Telefone:</b></td> 
<td style='padding: 6px; border: 1px solid #ccc;'>$ddd - $telefone </td>
</tr>
<tr>
<td valign='top' style='padding: 6px; border: 1px solid #ccc;'><b>Mensagem:</b></td>
<td style='padding: 6px; border: 1px solid #ccc;'> $mensagem </td>
</tr>
</table>
";

$mail->MsgHTML($body);
//adicionar os emails "atendimento@samaritanodf.org.br" e "jguidini@hotmail.com"
$address = "jonesguidini@gmail.com";

$mail->AddAddress($address, "Jos� Guidini");

	if(!$mail->Send()) {
		echo "Houve os seguintes erros: " . $mail->ErrorInfo;
	} else {
		//echo "Message sent!";
		header("Location: contato.php?status=msg_enviada"); 
	}

?>