    <div class="row-fluid menu_rodape">
  		<div class="container links-rodape">
  		<a href="index.php">Inicial</a>&nbsp;&nbsp;|&nbsp;&nbsp;
  		<a href="instituicao.php">A Institui��o</a>&nbsp;&nbsp;|&nbsp;&nbsp;
  		<a href="galeria.php">Galeria de Fotos</a>&nbsp;&nbsp;|&nbsp;&nbsp;
  		<a href="colabore.php">Colabore</a>&nbsp;&nbsp;|&nbsp;&nbsp;
  		<a href="artigos.php">Artigos</a>&nbsp;&nbsp;|&nbsp;&nbsp;
  		<a href="parceiros.php">Parceiros</a>&nbsp;&nbsp;|&nbsp;&nbsp;
  		<a href="contato.php">Fale Conosco</a>
  		</div>
  	</div>
  	
  	<div class="row-fluid">
  		<div class="container pagination-centered link-visuweb">
  			<i>Site desenvolvido por :</i><br> <span class="btn btn-small btn-success"><i class="icon-ok-circle icon-white"></i> <a href="http://www.visuweb.com.br" target="_blank">www.visuweb.com.br</a></span>
  		</div>
  	</div>