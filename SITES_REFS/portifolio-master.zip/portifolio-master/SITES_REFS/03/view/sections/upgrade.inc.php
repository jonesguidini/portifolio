<div class="modal fade" id="upgrade-dialog" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Your browser is out of date</h4>
			</div>
			<div class="modal-body">
				<p>To get the best possible experience using our site we recommend that you upgrade to a modern web browser. To download a newer web browser click on the Upgrade button.</p>
			</div>
			<div class="modal-footer">
				<a href="http://browsehappy.com/" target="_blank" class="btn btn-primary">Upgrade</a>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->